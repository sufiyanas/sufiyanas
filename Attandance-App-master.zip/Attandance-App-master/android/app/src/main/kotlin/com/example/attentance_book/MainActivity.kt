package com.example.attentance_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
